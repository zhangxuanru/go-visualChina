package engine

type Request struct {
   Url string
   Method string
   Content string
   Args RequestArgs
   Parser Parser
}

type Item struct {
	PublishMsg  PublishMsg
}

type RequestArgs struct {
	Id       int64
	Type     int
	UrlType  string
	GroupId  string
	Page     int
	PerPage  int64
	CategoryId int64
	ChannelId  int
	Data interface{}
	UrlInitArgs
}

type UrlInitArgs struct {
	Type int
	All bool
	GroupLimit int
	PicLimit   int
	TopicLimit  int
	IndexLimit  int
}


type ParseResult struct {
	Requests []Request
	Items    []Item
}

type PublishMsg struct {
	MsgType string
	DataType interface{}
	Data interface{}
	Args RequestArgs
}



type Parser interface {
	Parse(contents []byte,args RequestArgs) ParseResult
}

type ParserFunc func(contents []byte,args RequestArgs) ParseResult

type FuncParser struct {
	parser ParserFunc
	name string
}

func (f *FuncParser) Parse(contents []byte,args RequestArgs) ParseResult {
	return  f.parser(contents,args)
}


func NewFuncParser(p ParserFunc, name string) *FuncParser {
	return &FuncParser{
		parser:p,
		name:name,
	}
}


