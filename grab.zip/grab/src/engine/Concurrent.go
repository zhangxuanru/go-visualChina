package engine

import (
	"libary/logger"
	"sync"
	"libary/queue/nsqqueue"
	"encoding/json"
	"config/constant"
	"fmt"
)

var ws *sync.WaitGroup
var count *int

type ConcurrentEngine struct {
	Scheduler        Scheduler
	WorkerCount      int
	QueueServer      *nsqqueue.NSQpRoCer
}

type Scheduler interface {
	WorkerChan() chan Request
	Run()
	Submit(request Request)
}

func (c *ConcurrentEngine) Run(seeds ...Request)  {
	  seedsLen := len(seeds)
	  count = &seedsLen

	  out := make(chan ParseResult,1000)
	  c.Scheduler.Run()
	  for i:=0; i<c.WorkerCount;i++{
          c.CreateWorker(c.Scheduler.WorkerChan(),out)
	  }
	  for _,r := range seeds{
	  	   c.Scheduler.Submit(r)
	  }
	 for{
		ret := <-out
		rLen := len(ret.Requests)
		*count += rLen
		 for _,item := range ret.Items{
			 bytes, e := json.Marshal(item)
			 if e != nil{
				 continue
			 }
			 c.QueueServer.Publish(constant.NSQ_TOPIC,string(bytes))
		 }
		for _, request := range ret.Requests {
			if len(request.Url) < 5{
				*count--
				continue
			}
		     c.Scheduler.Submit(request)
		}
		if *count == 0{
		      break
		}
	}
}


func (c *ConcurrentEngine) CreateWorker(in chan Request, out chan ParseResult)  {
	go func() {
		for{
           request := <-in
		   result,err := FetchUrl(request)
		   fmt.Println(request.Url,"---Requests:",len(result.Requests),"----items:",len(result.Items),err)
		   if err != nil{
			    logger.Error.Println("抓取",request.Url,"失败，失败原因是:",err)
			    *count--
			    continue
		   }
			*count--
		    out <- result
		}
	}()
}

