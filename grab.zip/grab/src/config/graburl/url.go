package graburl

import (
	"engine"
	"analysis/editorial/parsingfunc"
)

type UrlInfo struct {
	 Url string
	 Name string
 	 ParseFunc engine.ParserFunc
}

func InitUrls() map[int]UrlInfo {
	urls := map[int] UrlInfo{
		0:{
			Url:"https://www.vcg.com/editorial",       //编辑图片
			Name:"editorial",
	 		ParseFunc:parsingfunc.ParseEditorial,
		},
		1:{
			Url:"https://www.vcg.com/sets/wallpaper",  //创意壁纸
			Name:"wallpaper",
		 	ParseFunc:parsingfunc.ParseEditorial,
		},
		2:{
			Url:"https://www.vcg.com/creative",        //创意图片
			Name:"creative",
		 	ParseFunc:parsingfunc.ParseEditorial,
		},
		3:{
			Url:"https://www.vcg.com/design",         //设计素材
			Name:"design",
		 	ParseFunc:parsingfunc.ParseEditorial,
		},
	}
	return urls
}
