package db

const (
	DB_DRIVER_NAME  = "mysql"
	DB_HOST         = "123.56.28.87"
	DB_PORT         = "3306"
	DB_USER         = "visual"
	DB_PASSWORD     = "zxrgoodgoodgood123"
	DB_DATABASE_NAME  = "visual_china"
    DB_CHARSET        = "utf8"
)



