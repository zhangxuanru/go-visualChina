package constant

const BaseUrl  = "https://www.vcg.com"

const GroupDataUrl  = "https://www.vcg.com/ajax/channel/tagitemlist"

const INDEXGROUPURL  = "https://www.vcg.com/ajax/editoral/subscribe"

const MAX_GROUP_DATA  = 100

const NSQ_SERVER  = "192.168.33.10:4150"
const NSQ_TOPIC   = "editorial"
const NSQ_CHANNEL  = "editorial-run"
const NSQ_ADDRESS  = "192.168.33.10:4161"

const TABLE_PRE  = "visual_editorial_"