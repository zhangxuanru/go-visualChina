// Package text provides rudimentary functions for manipulating text in
// paragraphs.
package text
