package nsq

// states
const (
	StateInit = iota
	StateDisconnected
	StateConnected
)
