package nsqadmin

type Context struct {
	nsqadmin *NSQAdmin
}
