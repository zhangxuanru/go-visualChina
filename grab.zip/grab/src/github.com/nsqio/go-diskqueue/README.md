# go-diskqueue
A Go package providing a filesystem-backed FIFO queue

Pulled out of https://github.com/nsqio/nsq
