# timer_metrics

A efficient way to capture timing information and periodically output metrics

[![Build Status](https://travis-ci.org/bitly/timer_metrics.png?branch=master)](https://travis-ci.org/bitly/timer_metrics)

See <https://godoc.org/github.com/bitly/timer_metrics>