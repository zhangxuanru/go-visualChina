# go-options

Resolve configuration values set via command line flags, config files, and default struct values.

[![Build Status](https://travis-ci.org/mreiferson/go-options.svg?branch=master)](https://travis-ci.org/mreiferson/go-options) [![GoDoc](https://godoc.org/github.com/mreiferson/go-options?status.svg)](https://godoc.org/github.com/mreiferson/go-options)
