package parsingjson

import "encoding/json"

type IndexJson struct {
	Data struct {
		Code    int    `json:"code"`
		Message string `json:"message"`
		Data   IndexData `json:"data"`
	} `json:"data"`
}

type IndexData  struct {
	SubList          []interface{} `json:"sub_list"`
	UnSubChannelList []UnSubChannelList `json:"un_sub_channel_list"`
	UnSubBrandList   []UnSubBrandList `json:"un_sub_brand_list"`
	UnSubAreaList    []UnSubAreaList `json:"un_sub_area_list"`
	BannerData       []BannerData `json:"bannerData"`
	AllScrollData    AllScrollData `json:"allScrollData"`
	SubChannelData   SubChannelData `json:"subChannelData"`
}

type UnSubChannelList   struct   {
	SearchVal    string `json:"search_val"`
	DisplayTxt   string `json:"display_txt"`
	DisplayOrder int    `json:"display_order"`
	SearchType   string `json:"search_type"`
	SearchKey    string `json:"search_key"`
	KeywordID    int    `json:"keyword_id"`
}

type UnSubBrandList  struct{
	SearchVal    string `json:"search_val"`
	DisplayTxt   string `json:"display_txt"`
	DisplayOrder int    `json:"display_order"`
	SearchType   string `json:"search_type"`
	SearchKey    string `json:"search_key"`
	KeywordID    int    `json:"keyword_id"`
}

type UnSubAreaList  struct {
	SearchVal    string `json:"search_val"`
	DisplayTxt   string `json:"display_txt"`
	DisplayOrder int    `json:"display_order"`
	SearchType   string `json:"search_type"`
	SearchKey    string `json:"search_key"`
	KeywordID    int    `json:"keyword_id"`
}

type BannerData  struct {
	Type          int    `json:"type"`
	ID            int    `json:"id"`
	Text          string `json:"text"`
	Path          string `json:"path"`
	Link          string `json:"link"`
	RecommendType int    `json:"recommend_type"`
	ImgWidth      int    `json:"img_width"`
	ImgHeight     int    `json:"img_height"`
}

type AllScrollData struct {
	TotalCount int `json:"total_count"`
	List       []AllScrollDataList `json:"list"`
}

type AllScrollDataList struct {
	ID           uint64       `json:"id"`
	GroupID      string      `json:"group_id"`
	OneCategory  int         `json:"oneCategory"`
	Category     interface{} `json:"category"`
	Title        string      `json:"title"`
	Caption      string      `json:"caption"`
	Width        int         `json:"width"`
	Height       int         `json:"height"`
	EqualwURL    string      `json:"equalw_url"`
	EqualhURL    string      `json:"equalh_url"`
	FirstResID   uint64      `json:"firstResId"`
	ImgDate      string      `json:"img_date"`
	GroupPicsNum int         `json:"group_pics_num"`
	Keywords     string      `json:"keywords"`
	Price        string      `json:"price"`
	URL800       string      `json:"url800"`
	OneCategoryCn interface{} `json:"oneCategoryCn"`
}


type SubChannelData struct {
	ChannelResult []ChannelResult `json:"channel_result"`
	BrandResult   []BrandResult `json:"brand_result"`
	AreaResult    []AreaResult `json:"area_result"`
}

type ChannelResult  struct {
	SearchVal    string `json:"search_val"`
	DisplayTxt   string `json:"display_txt"`
	DisplayOrder int    `json:"display_order"`
	SearchType   string `json:"search_type"`
	SearchKey    string `json:"search_key"`
}

type BrandResult struct {
	SearchVal    string `json:"search_val"`
	DisplayTxt   string `json:"display_txt"`
	DisplayOrder int    `json:"display_order"`
	SearchType   string `json:"search_type"`
	SearchKey    string `json:"search_key"`
}

type AreaResult  struct {
	SearchVal    string `json:"search_val"`
	DisplayTxt   string `json:"display_txt"`
	DisplayOrder int    `json:"display_order"`
	SearchType   string `json:"search_type"`
	SearchKey    string `json:"search_key"`
}

//index 下一页 json解析
type IndexNextPage struct {
	Status int `json:"status"`
	Code   int `json:"code"`
	Data   IndexNextData `json:"data"`
	Message interface{} `json:"message"`
}

type IndexNextData  struct {
	TotalCount int `json:"total_count"`
	List       []AllScrollDataList `json:"list"`
}



//首页JSON解析
func ParseAtlasJson(contents []byte) (ret *IndexJson,err error)  {
	var index IndexJson
	content,err := BaseParseJson(contents)
	if err != nil{
		return
	}
	json.Unmarshal([]byte(content),&index)
	return &index,nil
}

//首页下一页JSON解析
func ParseNextPageJson(content []byte) (ret *IndexNextPage,err error) {
	var index IndexNextPage
	json.Unmarshal(content,&index)
	return &index,nil
}

