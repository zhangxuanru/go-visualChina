package parsingjson

import (
	"regexp"
	"errors"
	"strings"
)

func BaseParseJson(contents []byte) (string,error)  {
	compile, err := regexp.Compile(`<script>window.__REDUX_STATE__(.*)</script>`)
	if err != nil{
		return "",err
	}
	find := compile.FindSubmatch(contents)
	if len(find)<2{
		return "",errors.New("FindSubmatch not match data ")
	}
	content := strings.TrimSpace(string(find[1]))
	content = strings.TrimFunc(content, func(r rune) bool {
		return r ==' ' || r ==';' || r == '='
	})
	return content,nil
}