package parsingjson

import (
	"encoding/json"
)

type ChannelJson struct {
	Data  ChannelData `json:"data"`
}

type ChannelData  struct {
	Data ChannelDataList `json:"data"`
}

type ChannelDataList  struct {
	ChannelID         int    `json:"channelID"`
	PictureGeneralize []PictureGeneralize `json:"pictureGeneralize"`
	LinkTags []LinkTags `json:"linkTags"`
	ChannelRecommend ChannelRecommend `json:"channelRecommend"`
	ChannelTag []ChannelTag `json:"channelTag"`
	ChannelTid     int `json:"channelTid"`
	ChannelDefault ChannelDefault `json:"channelDefault"`
}

type PictureGeneralize struct {
	ID            int         `json:"id"`
	Link          string      `json:"link"`
	Src           string      `json:"src"`
	Title         string      `json:"title"`
	Sort          int         `json:"sort"`
	ImgDate       string      `json:"img_date"`
	PicsNum       interface{} `json:"pics_num"`
	RecommendType int         `json:"recommendType"`
}

type LinkTags  struct {
	Link  string `json:"link"`
	Title string `json:"title"`
}

type ChannelRecommend struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
	Link string `json:"link"`
	Data []ChannelRecommendData `json:"data"`
}

type ChannelRecommendData  struct {
	ID            int    `json:"id"`
	Link          string `json:"link"`
	Src           string `json:"src"`
	Title         string `json:"title"`
	Sort          int    `json:"sort"`
	ImgDate       string `json:"img_date"`
	PicsNum       int    `json:"pics_num"`
	RecommendType int    `json:"recommendType"`
}

type ChannelTag struct {
	Code string `json:"code"`
	Name string `json:"name"`
	Pid  string `json:"pid"`
	ID   string `json:"id"`
}

type ChannelDefault struct {
	TotalCount int `json:"total_count"`
}

func ParseChannelJson(contents []byte)(ret *ChannelJson,err error){
	var channel ChannelJson
	content,err := BaseParseJson(contents)
	if err != nil{
		return
	}
	json.Unmarshal([]byte(content),&channel)
	return &channel,nil
}


