package banner

import (
	"engine"
	"github.com/goinggo/mapstructure"
	"libary/logger"
	"analysis/Model"
	"libary/upload"
	"time"
	"strings"
	"net/url"
	"strconv"
	"errors"
	"analysis/editorial/parsingHelper/helper"
	"fmt"
)

type Banner struct {
	Id              float64   `mapstructure:"id"`
	Text            string    `mapstructure:"text"`
	Path            string    `mapstructure:"path"`
	Link            string    `mapstructure:"link"`
	RecommendType   float64   `mapstructure:"recommend_type"`
	ImgWidth       float64    `mapstructure:"img_width"`
	ImgHeight      float64    `mapstructure:"img_height"`
	Type           float64    `mapstructure:"type"`
}

//将消息队列中的banner数据保存到数据库中
func SaveBannerQueueData(item engine.Item) (id int64,err error) {
	ret := ItemTOBannerData(item)
	if ret.Link == "" || ret.ID == 0{
		return 0,errors.New("ItemTOBannerData banner.link is null")
	}
	exists := helper.IsExists(ret.ID, item.PublishMsg.MsgType)
	if exists == false{
		 id,err = Model.SaveBanner(ret)
	}else{
		fmt.Printf("SaveBannerQueueData: %s---已存在:\n",ret.Link)
		return
	}
	if err != nil{
		fmt.Printf("SaveBannerQueueData: %s---保存失败,失败原因%v:\n",ret.Link,err)
		return
	}
	if exists == false && id > 0{
		fmt.Printf("SaveBannerQueueData: %s------Save OK:\n",ret.Link)
		helper.SaveBit(ret.ID, item.PublishMsg.MsgType)
	}
	if exists == false && id == 0{
		fmt.Printf("SaveBannerQueueData: %s---保存失败:\n",ret.Link)
	}
   return
}


//将MAP转为结构体
func ItemTOBannerData(item engine.Item) (ret Model.SaveBannerData) {
	data := item.PublishMsg.Data
	var banner Banner
	if err:= mapstructure.Decode(data, &banner); err != nil {
		logger.Error.Println("ItemTOGroupData -  nav map to struct error:",err)
		return
	}
	parse, _ := url.Parse(banner.Link)
	path := parse.Path
	Type := 3
	if strings.Contains(path,"topic"){
		Type = 2
	}
	if strings.Contains(path,"group"){
		Type = 1
	}
	linkId := strings.TrimLeft(path,"/group/")
	linkId = strings.TrimLeft(linkId,"/topic/")
	id,_ := strconv.Atoi(linkId)
	bannerData := Model.SaveBannerData{
		  ID:int(banner.Id),
          Type:Type,
		  ImgId:upload.UploadToQiniu(banner.Path),
		  Text:banner.Text,
		  OriginImgUrl:banner.Path,
		  Link:banner.Link,
		  LinkId:id,
		  RecommendType:int(banner.RecommendType),
		  ImgWidth:int(banner.ImgWidth),
		  ImgHeight:int(banner.ImgHeight),
		  AddDate:time.Now().Unix(),
	}
	return  bannerData
}



