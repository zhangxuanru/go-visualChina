package nav

import (
	"engine"
	"analysis/Model"
	"github.com/goinggo/mapstructure"
	"libary/logger"
	"analysis/editorial/parsingHelper/helper"
	"time"
	"fmt"
)

//将消息队列中的导航数据保存到数据库中
func SaveNavQueueData(item engine.Item) (id int64,err error) {
	 var navData Model.SaveNavData
	 data := item.PublishMsg.Data
	 //将 map 转换为指定的结构体
	 if err = mapstructure.Decode(data, &navData); err != nil {
	 	logger.Error.Println("SaveNavQueueData -  nav map to struct error:",err)
	 	return  0,err
	 }
	 exists := helper.IsExists(navData.CategoryId, item.PublishMsg.MsgType)
	if exists == false{
		navData.AddDate = time.Now().Unix()
		id, err = Model.SaveNav(navData)
	}else{
		fmt.Printf("SaveNavQueueData: %d : %s ---已存在:\n",navData.CategoryId,navData.NavName)
	}
	if exists == false && id >0 {
		fmt.Printf("SaveNavQueueData: %d : %s ---Save OK:\n",navData.CategoryId,navData.NavName)
		helper.SaveBit(navData.CategoryId, item.PublishMsg.MsgType)
	}
	if exists == false && id == 0{
		fmt.Printf("SaveNavQueueData: %d : %s ---保存失败:\n",navData.CategoryId,navData.NavName)
	}
	 return
}





