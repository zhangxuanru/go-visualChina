package group

import (
	"engine"
	"github.com/goinggo/mapstructure"
	"libary/logger"
	"fmt"
	"analysis/Model"
	"time"
	"strconv"
	"analysis/editorial/parsingHelper/helper"
	"errors"
	"libary/upload"
)

type groupData struct {
	Id              float64   `mapstructure:"id"`
	GroupId         string    `mapstructure:"group_id"`
	OneCategory     int       `mapstructure:"oneCategory"`
	Title           string    `mapstructure:"title"`
	Caption         string    `mapstructure:"caption"`
	FirstPicId      float64   `mapstructure:"firstResId"`
	GroupPicsNum    int64     `mapstructure:"group_pics_num"`
	Keywords        string    `mapstructure:"keywords"`
	ImgDate         string    `mapstructure:"img_date"`
	EqualwUrl        string   `mapstructure:"equalw_url"`
 	EqualhUrl        string   `mapstructure:"equalh_url"`
 	Width            float64  `mapstructure:"width"`
	Height           float64  `mapstructure:"height"`
	Url800           string   `mapstructure:"url800"`
}

//将消息队列中的group数据保存到数据库中
func SaveGroupQueueData(item engine.Item)  (id int64,err error)  {
	data := ItemTOGroupData(item)
	if data.GroupId == 0 {
		 return 0,errors.New("group.GroupId is null")
	}
	exists := helper.IsExists(data.GroupId, item.PublishMsg.MsgType)
	if exists == false{
		id, err = Model.SaveGroup(data)
	}else{
		fmt.Printf("SaveGroupQueueData: %d:%s---已存在:\n",data.GroupId,data.Title)
		return
	}
	if err != nil{
		logger.LogFile("queue-error.log","SaveGroupQueueData:",err)
		fmt.Printf("error:SaveGroupQueueData: %d:%s---error:%v:\n",data.GroupId,data.Title,err)
		return
	}
	if id > 0{
		_, e := Model.SaveGroupDetail(data)
		logger.LogFile("queue-error.log","SaveGroupQueueData:error:",e)
		SaveGroupES(data)
	}
	if exists == false && id > 0{
		fmt.Printf("SaveGroupQueueData: %d:%s---Save OK:\n",data.GroupId,data.Title)
		helper.SaveBit(data.GroupId, item.PublishMsg.MsgType)
	}
	if exists == false && id == 0{
		fmt.Printf("error:SaveGroupQueueData: %d:%s---保存失败:\n",data.GroupId,data.Title)
	}
    return
}



//将MAP转为结构体
func ItemTOGroupData(item engine.Item) (result Model.SaveGroupData) {
	data := item.PublishMsg.Data
	var group groupData
	if err:= mapstructure.Decode(data, &group); err != nil {
		logger.Error.Println("ItemTOGroupData -  nav map to struct error:",err)
		return
	}
	groupId,_ := strconv.ParseUint(group.GroupId,10,64)
	firstPicId:= strconv.FormatFloat(group.FirstPicId,'f',-1,64)
	result = Model.SaveGroupData{
		GroupId:groupId,
		OneCategory:group.OneCategory,
		Title:group.Title,
		FirstPicId:firstPicId,
		Status:1,
		GroupPicsNum:group.GroupPicsNum,
		Keywords:group.Keywords,
		ImgDate:helper.DataToTime(group.ImgDate),
		EqualwUrl:group.EqualwUrl,
		EqualwImageId:upload.UploadToQiniu(group.EqualwUrl),
		EqualhUrl:group.EqualhUrl,
		EqualhImageId:upload.UploadToQiniu(group.EqualhUrl),
		Width:int64(group.Width),
		Height:int64(group.Height),
		Url800:group.Url800,
		Url800ImageId:upload.UploadToQiniu(group.Url800),
		Caption:group.Caption,
		AddDate:time.Now().Unix(),
	}
	return result
}

 //保group数据保存到ES中，将keywords拆分出来， 每个分类建一个索引，索引下存放group_id
 //按分类搜索， 按关键词搜索
func SaveGroupES(data Model.SaveGroupData)  {

}

