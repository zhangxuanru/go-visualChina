package Index

import (
	"analysis/Model"
	"engine"
	"analysis/editorial/parsingjson"
	"analysis/editorial/parsingHelper/helper"
)
var Key = 0

//发布导航消息
func ProcessNavData(navData []Model.SaveNavData,items []engine.Item,args engine.RequestArgs){
	i := &Key
	for _,item := range navData{
		items[*i] = helper.NewItemPublishMsg("saveNav","Model.SaveNavData",item,args)
		*i++
	}
}


//发布分类消息
func ProcessChannelData(channlList []parsingjson.ChannelResult,items []engine.Item,args engine.RequestArgs){
	i := &Key
	for _,item := range channlList{
		items[*i] = helper.NewItemPublishMsg("saveChannel","parsingjson.ChannelResult",item,args)
		*i++
	}
}

//发布grouplist 消息
func ProcessGroupList(groupList []parsingjson.AllScrollDataList,items []engine.Item,args engine.RequestArgs)  {
	i := &Key
	for _,item := range groupList{
		items[*i] = helper.NewItemPublishMsg("saveGroupList","parsingjson.AllScrollDataList",item,args)
		*i++
	}
}

//发布banner 数据
func ProcessBannerData(bannerData []parsingjson.BannerData,items []engine.Item,args engine.RequestArgs)  {
	i := &Key
	for _,item := range bannerData{
		   items[*i] = helper.NewItemPublishMsg("saveBannerData","parsingjson.BannerData",item,args)
		   *i++
	}
}

// 发布所有消息--nsq
func ProcessPublishData(data  IndexData,items []engine.Item,args engine.RequestArgs)  {
	//nav
	ProcessNavData(data.NavData,items,args)
	//channel
	ProcessChannelData(data.ChannelList,items,args)
	//grouplist
	ProcessGroupList(data.GroupList,items,args)
    //banner data
	ProcessBannerData(data.BannerData,items,args)
}

////发布消息item的格式
//func newItemPublishMsg(msgType string,dataType interface{},Data interface{},args engine.RequestArgs) (item engine.Item) {
//	item = engine.Item{
//		PublishMsg:engine.PublishMsg{
//			MsgType : msgType,
//			DataType: dataType,
//			Data    : Data,
//            Args    : args.UrlInitArgs,
//		},
//	}
//	return item
//}
