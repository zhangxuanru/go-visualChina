package Index

import (
	"libary/query"
	"analysis/editorial/parsingjson"
	"analysis/Model"
	"engine"
	"strconv"
	"strings"
)

type IndexData struct {
	NavList      map[int]query.NavData
	ChannelList  []parsingjson.ChannelResult
	NavData      []Model.SaveNavData
	GroupList    []parsingjson.AllScrollDataList
	BannerData   []parsingjson.BannerData
} 

//整理导航数据将标题，URL，抓取分类整合在一起
func CombineNavDataAndJson(channelList []parsingjson.ChannelResult,  navList map[int]query.NavData,
	args engine.RequestArgs) (navData []Model.SaveNavData) {
    for _,nav := range navList{
		navItem := Model.SaveNavData{
			NavName:nav.Title,
			GrabUrl:nav.Url,
			Type:args.UrlInitArgs.Type,
		}
		if navItem.NavName =="专题"{
			navItem.CategoryId = 1
		}
		if navItem.NavName =="滚动"{
			navItem.CategoryId = 2
		}
		if navItem.NavName =="最佳"{
			navItem.CategoryId = 3
		}
		if navItem.NavName =="原创"{
			navItem.CategoryId = 4
		}
    	for _,channel := range channelList{
            if  strings.EqualFold(channel.DisplayTxt,nav.Title){
				       categoryId,_ := strconv.ParseInt(channel.SearchVal,10,64)
                       navItem.CategoryId = categoryId
                       break
					  }
			}
		   navData = append(navData,navItem)
		}
	return  navData
}


//获取导航对应的分类列表
func GetIndexChannList(json parsingjson.SubChannelData) ([]parsingjson.ChannelResult) {
	var channelList []parsingjson.ChannelResult
	for _,item := range json.ChannelResult{
		if  strings.Contains(item.SearchVal,"|"){
			continue
		}
		item.DisplayTxt = strings.TrimSpace(item.DisplayTxt)
		channelList = append(channelList,item)
	}
	return  channelList
}

//获取首页group列表
func GetIndexGroupList(json parsingjson.AllScrollData)(ret []parsingjson.AllScrollDataList)  {
       return  json.List
}

//获取首页banner列表
func GetBannerData(json parsingjson.IndexData) (ret []parsingjson.BannerData) {
	  return json.BannerData
}


//整理首页所有数据
func GetIndexData(contents []byte,json parsingjson.IndexData,args engine.RequestArgs) (data IndexData, i int) {
	navList := query.ParseNavDocument(contents)
	channelList := GetIndexChannList(json.SubChannelData)
	groupList   := GetIndexGroupList(json.AllScrollData)
	bannerData  := GetBannerData(json)

	data = IndexData{
		ChannelList: channelList,
		NavData:     CombineNavDataAndJson(channelList, navList, args),
		GroupList:   groupList,
		BannerData:  bannerData,
	}
	return  data, GetItemLen(data)
}


//获取首页所有数据的长度
func GetItemLen(data IndexData) (l int) {
    return  len(data.NavData)+len(data.ChannelList)+len(data.GroupList)+len(data.BannerData)
}



