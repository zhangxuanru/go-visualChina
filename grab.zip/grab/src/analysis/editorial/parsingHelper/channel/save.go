package channel

import (
	"engine"
	"github.com/goinggo/mapstructure"
	"libary/logger"
	"analysis/Model"
	"strconv"
	"time"
	"analysis/editorial/parsingHelper/helper"
	"errors"
	"fmt"
	"net/url"
	"strings"
	"libary/upload"
)

type channelData  struct {
	SearchVal    string `mapstructure:"search_val"`
	DisplayTxt   string `mapstructure:"display_txt"`
	DisplayOrder int    `mapstructure:"display_order"`
}

type LinkTagsData struct {
	Link  string  `mapstructure:"link"`
	Title string  `mapstructure:"title"`
}

type PictureGeneralize struct {
	ID            int           `mapstructure:"id"`
	Link          string        `mapstructure:"link"`
	Src           string        `mapstructure:"src"`
	Title         string        `mapstructure:"title"`
	Sort          int           `mapstructure:"sort"`
	RecommendType int           `mapstructure:"recommendType"`
}


//index--将消息队列中的分类数据保存到数据库中
func SaveChannelQueueData(item engine.Item) (id int64,err error)  {
	channel := ItemTOChannelData(item)
	if channel.CategoryId == 0{
		 return 0,errors.New("CategoryId is 0")
	}
	exists := helper.IsExists(channel.CategoryId, item.PublishMsg.MsgType)
	if exists == false{
		id, err = Model.SaveChannel(channel)
	}else{
		fmt.Printf("SaveChannelQueueData: %d:%s---已存在:\n",channel.CategoryId,channel.CategoryName)
	}
	if exists == false && id > 0{
		fmt.Printf("SaveChannelQueueData: %d:%s---Save OK:\n",channel.CategoryId,channel.CategoryName)
		helper.SaveBit(channel.CategoryId, item.PublishMsg.MsgType)
	}
	if exists == false && id == 0{
		fmt.Printf("SaveChannelQueueData: %d:%s---保存失败:\n",channel.CategoryId,channel.CategoryName)
	}
   return
}

//将channel数据转为可直接保存数据库的的channel结构
func ItemTOChannelData(item engine.Item) (model Model.SaveChannelData) {
	  data := item.PublishMsg.Data
	  args := item.PublishMsg.Args
	  var channel channelData
	  if err:= mapstructure.Decode(data, &channel); err != nil {
		  logger.Error.Println("SaveNavQueueData -  nav map to struct error:",err)
		  return
	  }
	categoryId,_ := strconv.ParseInt(channel.SearchVal,10,64 )
	channelData := Model.SaveChannelData{
         CategoryId: categoryId,
		 CategoryName:channel.DisplayTxt,
         Type:args.Type,
		 Order:channel.DisplayOrder,
		 Status:1,
		 AddDate:time.Now().Unix(),
	}
	return channelData
}

//保存二级栏目页上面的的linkTags
func SaveChannelQueueLinkTags(item engine.Item) (id int64,err error) {
	linkTags := ItemToLinkData(item)
	if linkTags.CategoryId == 0{
		return 0,errors.New("linkTags CategoryId is 0")
	}
	bitKey := fmt.Sprintf("%s_%d_%d",item.PublishMsg.MsgType,linkTags.CategoryId,linkTags.ItemType)
	exists := helper.IsExists(linkTags.ItemId, bitKey)
	if exists == false{
		id, err = Model.SaveLinkTags(linkTags)
	}else{
		fmt.Printf("SaveChannelQueueLinkTags: %d:%s---已存在:\n",linkTags.ItemId,linkTags.Title)
	}
	if exists == false && id > 0{
		fmt.Printf("SaveChannelQueueLinkTags: %d:%s---Save OK:\n",linkTags.ItemId,linkTags.Title)
		helper.SaveBit(linkTags.ItemId,bitKey)
	}
	if exists == false && id == 0{
		fmt.Printf("SaveChannelQueueLinkTags: %d:%s---保存失败:\n",linkTags.ItemId,linkTags.Title)
	}
	return
}

//将item linkTags 转为MODEL数据结构
func ItemToLinkData(item engine.Item) (linkTags Model.SaveLinkTagsData) {
	data := item.PublishMsg.Data
	var tags  LinkTagsData
	if err:= mapstructure.Decode(data, &tags); err != nil {
		logger.Error.Println("SaveChannelQueueLinkTags -  linkTags map to struct error:",err)
		return
	}
	parse, _ := url.Parse(tags.Link)
	path := parse.Path
	Type := 0
	if strings.Contains(path,"topic"){
		Type = 2
	}
	if strings.Contains(path,"group"){
		Type = 1
	}
	linkId := strings.TrimLeft(path,"/group/")
	linkId = strings.TrimLeft(linkId,"/topic/")
	id,_ := strconv.Atoi(linkId)
	linkTags = Model.SaveLinkTagsData{
		Title: tags.Title,
		Link:  tags.Link,
		ItemId : int64(id),
		ItemType:Type,
		CategoryId: item.PublishMsg.Args.CategoryId,
		Type:item.PublishMsg.Args.Type,
		AddDate:time.Now().Unix(),
	}
	return linkTags
}


//保存二级栏目页底部的推广数据
func SaveQueuePictureGeneralizeData(item engine.Item) (id int64,err error) {
	generalizeData := ItemToPictureGeneralizeData(item)
	if generalizeData.CategoryId == 0{
		 return 0,errors.New("linkTags CategoryId is 0")
	}
	bitKey := fmt.Sprintf("%s_%d_%d",item.PublishMsg.MsgType,generalizeData.CategoryId,generalizeData.ItemType)
	exists := helper.IsExists(generalizeData.ItemId, bitKey)
	if exists == false{
		id, err = Model.SaveGeneralize(generalizeData)
	}else{
		fmt.Printf("SaveQueuePictureGeneralizeData: %d:%s---已存在:\n",generalizeData.ItemId,generalizeData.Title)
	}
	if exists == false && id > 0{
		fmt.Printf("SaveQueuePictureGeneralizeData: %d:%s---Save OK:\n",generalizeData.ItemId,generalizeData.Title)
		helper.SaveBit(generalizeData.ItemId,bitKey)
	}
	if exists == false && id == 0{
		fmt.Printf("SaveQueuePictureGeneralizeData: %d:%s---保存失败:\n",generalizeData.ItemId,generalizeData.Title)
	}
	return
}



//将item pictureGeneralize 转为MODEL可保存的数据结构
func ItemToPictureGeneralizeData(item engine.Item) ( generalizeData Model.SaveGeneralizeData) {
	data := item.PublishMsg.Data
	var generalize  PictureGeneralize
	if err:= mapstructure.Decode(data, &generalize); err != nil {
		logger.Error.Println("SaveQueuePictureGeneralizeData -  generalize map to struct error:",err)
		return
	}
	parse, _ := url.Parse(generalize.Link)
	path := parse.Path
	Type := 0
	if strings.Contains(path,"topic"){
		Type = 2
	}
	if strings.Contains(path,"group"){
		Type = 1
	}
	linkId := strings.TrimLeft(path,"/group/")
	linkId = strings.TrimLeft(linkId,"/topic/")
	id,_ := strconv.Atoi(linkId)
	generalizeData = Model.SaveGeneralizeData{
		Title: generalize.Title,
		Link:  generalize.Link,
		Sort:  generalize.Sort,
		Src:   generalize.Src,
		ImageId: upload.UploadToQiniu(generalize.Src),
		ItemId : int64(id),
		ItemType:Type,
		CategoryId: item.PublishMsg.Args.CategoryId,
		Type:item.PublishMsg.Args.Type,
		AddDate:time.Now().Unix(),
	}
	return generalizeData
}
