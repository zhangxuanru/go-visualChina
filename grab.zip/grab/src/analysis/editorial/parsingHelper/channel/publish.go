package channel

import (
	"engine"
	"analysis/editorial/parsingjson"
	"analysis/editorial/parsingHelper/helper"
)
var Key = 0

// 发布所有消息--nsq
func ProcessPublishData(data ChData,items []engine.Item,args engine.RequestArgs)  {
	//linkTags
	ProcessLinkTagsData(data.LinkTags,items,args)
	//PictureGeneralize
	ProcessPictureGeneralizeData(data.PictureGeneralize,items,args)
	//ChannelRecommend
	ProcessChannelRecommendData(data.ChannelRecommend,items,args)
	//ChannelTag
	ProcessChannelTag(data.ChannelTag,items,args)
}

//发布二级栏目页上面的链接tag
func ProcessLinkTagsData(linkTags []parsingjson.LinkTags,items []engine.Item,args engine.RequestArgs)  {
	i := &Key
    for _,item := range linkTags{
		items[*i] = helper.NewItemPublishMsg("saveChannelLinkTags","parsingjson.LinkTags",item,args)
	    *i++
	}
}

//发布二级栏目页下面的相关推广数据
func ProcessPictureGeneralizeData(data []parsingjson.PictureGeneralize,items []engine.Item,args engine.RequestArgs)  {
	i := &Key
	for _,item := range data{
		items[*i] = helper.NewItemPublishMsg("saveChannelPictureGeneralizeData","parsingjson.PictureGeneralize",item,args)
		*i++
	}
}

//发布二级栏目页推荐数据
func ProcessChannelRecommendData(data parsingjson.ChannelRecommend,items []engine.Item,args engine.RequestArgs)  {
	i := &Key
	for _,item := range data.Data{
		items[*i] = helper.NewItemPublishMsg("saveChannelRecommendData","parsingjson.ChannelRecommendData",item,args)
		*i++
	}
}

//发布二级栏目页tag标签
func ProcessChannelTag(data []parsingjson.ChannelTag,items []engine.Item,args engine.RequestArgs)  {
	i := &Key
	for _,item := range data{
		items[*i] = helper.NewItemPublishMsg("saveChannelTag","parsingjson.ChannelTag",item,args)
		*i++
	}
}
