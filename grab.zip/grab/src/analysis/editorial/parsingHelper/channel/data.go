package channel

import (
	"analysis/editorial/parsingjson"
)

type ChData struct {
	PictureGeneralize []parsingjson.PictureGeneralize
	LinkTags []parsingjson.LinkTags
	ChannelRecommend parsingjson.ChannelRecommend
	ChannelTag []parsingjson.ChannelTag
	ChannelDefault parsingjson.ChannelDefault
	ChannelID      int
}

func GetItemLen(data ChData) (i int) {
	return len(data.PictureGeneralize) +len(data.LinkTags) +len(data.ChannelRecommend.Data)+len(data.ChannelTag)
}

//整理渠道所有数据
func GetChannelData(json parsingjson.ChannelDataList) (data ChData, i int) {
	data = ChData{
		LinkTags: json.LinkTags,
		PictureGeneralize: json.PictureGeneralize,
		ChannelRecommend:  json.ChannelRecommend,
		ChannelTag:  json.ChannelTag,
		ChannelDefault:json.ChannelDefault,
		ChannelID : json.ChannelID,
	}
    return  data, GetItemLen(data)
}


