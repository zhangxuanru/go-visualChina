package helper

import (
	"libary/redis"
)

func IsExists(id interface{},Type string) (bool) {
	reply, _ :=   redis.Conn.Do("GETBIT", Type, id)
	i,_ := reply.(int64)
	if i == 1 {
		return true
	}
	 return false
}

func SaveBit(id interface{},Type string)  {
	redis.Conn.Do("SETBIT",Type,id,1)
}


