package helper

import (
	"time"
	"engine"
)

func DataToTime(date string) (int64) {
	location, _ := time.LoadLocation("Local")
	imgDate, _ := time.ParseInLocation("2006-01-02 15:04:05", date, location)
	return imgDate.Unix()
}

//发布消息item的格式
func NewItemPublishMsg(msgType string,dataType interface{},Data interface{},args engine.RequestArgs) (item engine.Item) {
	item = engine.Item{
		PublishMsg:engine.PublishMsg{
			MsgType : msgType,
			DataType: dataType,
			Data    : Data,
			Args    : args,
		},
	}
	return item
}
