package dataService

import (
	"engine"
	"analysis/editorial/parsingHelper/nav"
	"analysis/editorial/parsingHelper/channel"
	"analysis/editorial/parsingHelper/group"
	"analysis/editorial/parsingHelper/banner"
)

func CallData(item engine.Item)  {
	  msgType := item.PublishMsg.MsgType
	switch msgType {
	case "saveNav":
		  nav.SaveNavQueueData(item)
	case "saveChannel":
		 channel.SaveChannelQueueData(item)
	case "saveGroupList":
		 group.SaveGroupQueueData(item)
	case "saveBannerData":
		 banner.SaveBannerQueueData(item)
	case "saveChannelLinkTags":
         channel.SaveChannelQueueLinkTags(item)
	case "saveChannelPictureGeneralizeData":
         channel.SaveQueuePictureGeneralizeData(item)
	case "saveChannelRecommendData":
	case "saveChannelTag":
		
		
	}

}





