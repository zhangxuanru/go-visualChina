package parsingfunc

import "engine"


//最佳-栏目， 没有请求ID，
func ParseBest(contents []byte, args engine.RequestArgs) engine.ParseResult {

	return engine.ParseResult{}
}
