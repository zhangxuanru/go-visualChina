package parsingfunc

import (
	"engine"
	"fmt"
)

//专题，根据专题ID 返回专题的request,
func  ParseTopic(contents []byte, args engine.RequestArgs) engine.ParseResult  {

	return engine.ParseResult{}
}

//没有专题ID， 返回整个列表的专题request
func  ParseTopicList(contents []byte, args engine.RequestArgs) engine.ParseResult  {
	fmt.Println("ParseTopicList:")
	return engine.ParseResult{}
}

