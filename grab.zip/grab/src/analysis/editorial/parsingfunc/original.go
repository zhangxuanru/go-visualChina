package parsingfunc

import "engine"


//原创栏目，返回原创栏目的 request，请求参数中带有 ID
func  ParseOriginal(contents []byte, args engine.RequestArgs) engine.ParseResult  {

	return engine.ParseResult{}
}


