package parsingfunc

import "engine"

//根据groupid获取图片，并返回图片的详情request
func  ParseGroup(contents []byte, args engine.RequestArgs) engine.ParseResult  {

	return engine.ParseResult{}
}

