package parsingfunc

import (
	"engine"
	"analysis/editorial/parsingjson"
	"analysis/editorial/parsingHelper/channel"
)

//导航链接的二级页面， 抓取二级页面的子导航，上下推荐数据,带有分类ID过来
func ParseChannel(contents []byte, args engine.RequestArgs) engine.ParseResult {
	ret := engine.ParseResult{}
	if len(contents) == 0{
		 return ret
	}
	json, err := parsingjson.ParseChannelJson(contents)
	if err != nil{
	    return ret
	}
	jsonData := json.Data.Data
	args.ChannelId = jsonData.ChannelID
	data, itemLen := channel.GetChannelData(jsonData)
	if itemLen == 0{
		return ret
	}
	ret.Items = make([]engine.Item,itemLen+5)
	i := &channel.Key
	*i = 0
	//发布所有消息数据
	channel.ProcessPublishData(data,ret.Items,args)
	return ret
}
