package parsingfunc

import (
	"engine"
	"fmt"
	"analysis/editorial/parsingjson"
	"analysis/editorial/parsingHelper/Index"
	"config/constant"
	"strings"
	"libary/logger"
)

//抓取出左侧导航的链接
//解析页面的JSON，找出分类，然后与导航配对
//返回request 导航的链接，把每个导航对应的推荐数据与子分类拿出来，
//返回request,保存首页的group数据
//用redis中的bitmaps来记录是否已经保存过
var (
	indexCount = 0
	requestCount = 0
	)

//抓取 编辑图片首页内容
func ParseEditorial(contents []byte, args engine.RequestArgs) engine.ParseResult  {
	//表示只抓取首页group数据，不抓取其它栏目
	if args.UrlInitArgs.IndexLimit > 0{
          return ParseEditorialIndex(contents,args)
	}
	ret := engine.ParseResult{}
	if len(contents) == 0{
		  return ret
	}
	fmt.Println("ParseEditorial-----:")
	json, err := parsingjson.ParseAtlasJson(contents)
	if err != nil{
		  return ret
	}
	//获取首页所有数据
	data,itemLen := Index.GetIndexData(contents, json.Data.Data, args)
	//发布所有消息数据
	ret.Items = make([]engine.Item,itemLen+10)
	Index.ProcessPublishData(data,ret.Items,args)
	count := &indexCount
	*count += len(data.GroupList)
	/*返回所有的request
	  1.下一页
	  2.nav导航request
	  3.banner详情, topic专题详情
	  4.group 详情
	*/
	ret.Requests = make([]engine.Request,itemLen+20)
	processIndexRequestData(data,args,ret.Requests)
	return  ret
}


//只抓取首页grouplist数据和banner数据，不做其它处理,主要用于只做更新操作时
func ParseEditorialIndex(contents []byte, args engine.RequestArgs) engine.ParseResult  {
	ret := engine.ParseResult{}
	if args.IndexLimit <= 0{
		logger.Info.Println("grab IndexLimit is 0 ")
		return ret
	}
	json, err := parsingjson.ParseAtlasJson(contents)
	if err != nil{
		 return ret
	}
	groupList   := Index.GetIndexGroupList(json.Data.Data.AllScrollData)
	banner      := Index.GetBannerData(json.Data.Data)
	data := Index.IndexData{
		 GroupList : groupList,
		 BannerData : banner,
	}
	ret.Items = make([]engine.Item,len(groupList)+len(banner)+10)
	ret.Requests = make([]engine.Request,len(groupList)+len(banner)+20)
	Index.ProcessGroupList(groupList,ret.Items,args)
	Index.ProcessBannerData(banner,ret.Items,args)
	indexRequestGroupData(data,ret.Requests,args)
	indexRequestBannerData(data,ret.Requests,args)
	count := &indexCount
	*count += len(groupList)
	if args.IndexLimit <= *count{
		return ret
	}
	indexRequestNextPage(args,ret.Requests)
	return ret
}



//返回所有的request数据
func processIndexRequestData(data Index.IndexData,args engine.RequestArgs, requests []engine.Request)  {
	 indexRequestNextPage(args,requests)
	 indexRequestNavData(data,requests,args)
	 indexRequestBannerData(data,requests,args)
	 indexRequestGroupData(data,requests,args)
}

//request 下一页grouplist 数据
func indexRequestNextPage(args engine.RequestArgs, requests []engine.Request) {
	count := &indexCount
	if args.IndexLimit > 0 &&  args.IndexLimit <= *count{
		 return
	}
	if constant.MAX_GROUP_DATA <= *count {
		 return
	}
	i := &requestCount
	if args.Page == 0{
		 args.Page = 2
	}
	requests[*i] = engine.Request{
		Url:GetIndexUrl(args.Page,100),
		Parser:engine.NewFuncParser(pageIndexData,""),
		Args: engine.RequestArgs{
			UrlInitArgs:engine.UrlInitArgs{
				 IndexLimit:args.IndexLimit,
				 Type:args.UrlInitArgs.Type,
			},
			Page:args.Page+1,
			UrlType:"indexNextPage",
		},
	}
}

//request nav导航
func indexRequestNavData(data Index.IndexData,requests []engine.Request,args engine.RequestArgs)  {
	i := &requestCount
	*i++
	for _,item := range  data.NavData{
		 var (
		 	parser = ParseChannel
		 	Type = "channel"
		 )
		 if strings.Contains(item.GrabUrl,"update"){
              continue
		 }
	    //原创
	    if strings.Contains(item.GrabUrl,"original"){
			    parser = ParseOriginal
			    Type="original"
		 }
	    //专题
	    if strings.Contains(item.GrabUrl,"topics"){
				parser = ParseTopicList
		        Type = "topicList"
	    }
	   //最佳
	   if strings.Contains(item.GrabUrl,"best"){
			  parser = ParseBest
		      Type = "Best"
	   }
		requests[*i] = engine.Request{
			Url:item.GrabUrl,
			Parser:engine.NewFuncParser(parser,""),
			Args: engine.RequestArgs{
				UrlInitArgs: engine.UrlInitArgs{
					PicLimit:   args.PicLimit,
					TopicLimit: args.TopicLimit,
					Type:args.UrlInitArgs.Type,
				},
				 CategoryId:item.CategoryId,
				 UrlType: Type,
			},
		 }
     *i++
	}
 }

 //request bannerData
func indexRequestBannerData(data Index.IndexData,requests []engine.Request,args engine.RequestArgs)  {
	i := &requestCount
	*i++
	for _,item := range data.BannerData{
		var (
			parFun = ParseGroup
			argsType ="group"
			linkId = strings.TrimLeft(item.Link,"/topic/")
		)
		linkId = strings.TrimLeft(linkId,"/group/")
		if item.Type == 2{
             parFun = ParseTopic
			 argsType = "topic"
		 }
		 linkUrl := item.Link
		 if strings.Contains(linkUrl,"http") == false{
			 linkUrl = constant.BaseUrl+item.Link
		 }
		requests[*i] = engine.Request{
			Url:linkUrl,
			Parser:engine.NewFuncParser(parFun,""),
			Args: engine.RequestArgs{
				UrlInitArgs: engine.UrlInitArgs{
					PicLimit:   args.PicLimit,
					TopicLimit: args.TopicLimit,
					Type:args.UrlInitArgs.Type,
				},
				GroupId: linkId,
				UrlType  : argsType,
			},
		}
	 *i++
	}
}

//request groupList
func indexRequestGroupData(data Index.IndexData,requests []engine.Request,args engine.RequestArgs)  {
	i := &requestCount
	*i++
	for _,item := range data.GroupList{
		requests[*i] = engine.Request{
			Url:constant.BaseUrl+"/group/"+item.GroupID,
			Parser:engine.NewFuncParser(ParseGroup,""),
			Args: engine.RequestArgs{
				UrlInitArgs: engine.UrlInitArgs{
					PicLimit: args.PicLimit,
					Type:args.UrlInitArgs.Type,
				},
				GroupId: item.GroupID,
				UrlType  : "group",
			},
		}
	 *i++
	}
}


//下一页分页数据处理
func pageIndexData(contents []byte,args engine.RequestArgs) engine.ParseResult {
	ret := engine.ParseResult{}
	count := &indexCount
	key := &Index.Key
	i := &requestCount
	*key = 0
	*i   = 0
	json, err := parsingjson.ParseNextPageJson(contents)
	if err != nil{
		 return ret
	}
	groupList := json.Data.List
	data := Index.IndexData{
		GroupList : groupList,
	}
	ret.Items = make([]engine.Item,len(groupList)+10)
	ret.Requests = make([]engine.Request,len(groupList)+20)
	Index.ProcessGroupList(groupList,ret.Items,args)
	indexRequestGroupData(data,ret.Requests,args)
	*count += len(groupList)
	indexRequestNextPage(args,ret.Requests)
	return ret
}


func GetIndexUrl(page int,per_page int,)(url string)  {
	return fmt.Sprintf(constant.INDEXGROUPURL+"?page=%d&per_page=%d&isEdit=1",page,per_page)
}



//滚动二级页（将分类ID保存到导航表中）
func ParseEditorialUpdateOriginal(contents []byte,url string,args engine.RequestArgs) engine.ParseResult {
	//return  engine.ParseResult{}
	//
	//if args.Update == "1"{ //如果只抓最新的数据则不需要做以下的操作
	//	 return engine.ParseResult{}
	//}
	//fmt.Println("抓取",args.Title,"---栏目开始:")
	//reader := strings.NewReader(string(contents))
	//document, e := goquery.NewDocumentFromReader(reader)
	//if e != nil {
	//	logger.Error.Println("grab url ",url," args:",args," goquery error:",e)
	//	return engine.ParseResult{}
	//}
	//catList := query.ParseEditorialUpdate(document)
	//for catId,title := range catList{
	//	nav:= Model.NavDb{
	//		Title: title,
	//	    CategoryId:catId,
	//	}
	//	nav.UpdateNavCategoryIdByTitle()
	//}
	 return engine.ParseResult{}
}


//抓取栏目 二级页
func ParseEditorialNavLevelPage(contents []byte,url string,args engine.RequestArgs) engine.ParseResult {
	return engine.ParseResult{}

	//if args.Update == "1"{ //如果只抓最新的数据则不需要做以下的操作
	//	return getGroupDataByNavId(args.Id)
	//}
	//reader := strings.NewReader(string(contents))
	//document, e := goquery.NewDocumentFromReader(reader)
	//if e != nil {
	//	logger.Error.Println("grab url ",url," args:",args," goquery error:",e)
	//	return engine.ParseResult{}
	//}
	//tagList := query.ParseEditorialLevelPage(document)
	////保存tag
	//for _,tag := range tagList{
	//	  tag.Type = args.Type
     //     editorial.SaveTag(tag)
	//}
	////保存栏目页面底部推广数据
	//generalizeList := query.ParseEditorialLevelGeneralize(document)
	//for _,genera := range generalizeList{
	//	imageId := upload.UploadToQiniu(genera.Src)
	//	genera.ImageId = strconv.FormatInt(imageId,10)
	//	editorial.SaveGenera(genera)
	//}
	////保存栏目页上面的推荐数据
	//levelRecommend := query.ParseEditorialLevelRecommend(document)
	//for _,recommend := range levelRecommend{
     //      editorial.SaveRecommend(recommend)
	//}
	//return  getGroupDataByNavId(args.Id)
}
