package Model

import (
	"fmt"
	"libary/db"
	"libary/logger"
)

type SaveGeneralizeData  struct {
	Id              int64
	Title           string
	Link            string
	Src             string
	Sort            int
	ItemId          int64
	ItemType        int
	CategoryId      int64
	ImageId         int64
	Type            int
	recommendType   int
	AddDate         int64
}


func getGeneralizeTable() (table string) {
	return getTable("generalize")
}


//保存栏目页底部的图片推广数据
func SaveGeneralize(data SaveGeneralizeData) (id int64, err error) {
	sql := fmt.Sprintf("INSERT INTO %s ( `title`,`link`,`src`,`sort`,`type`,`category_id`,`image_id`,`item_id`,`item_type`,`recommend_type`,`add_date`) " +
		"VALUES('%s','%s','%s',%d,%d,%d,%d,%d,%d,%d,%d)",
		getGeneralizeTable(),data.Title,data.Link,data.Src,data.Sort,data.Type,data.CategoryId,data.ImageId, data.ItemId, data.ItemType,data.recommendType, data.AddDate)
	id, err = db.Insert(sql)
	if err != nil{
		logger.Error.Println("sql insert error:",err,"sql:",sql)
		return 0,err
	}
	return
}



