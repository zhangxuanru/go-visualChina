package Model

import "config/constant"

func getTable(tableName string) (table string) {
	return constant.TABLE_PRE+tableName
}

