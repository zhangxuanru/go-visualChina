package Model

import (
	"fmt"
	"libary/db"
	"libary/logger"
)

type SaveGroupData struct {
	Id              int64
	GroupId         uint64
	OneCategory     int
	Title           string
	Status          int
 	FirstPicId      string
	GroupPicsNum    int64
	Keywords        string
	ImgDate         int64
	EqualwUrl        string
	EqualwImageId    int64
	EqualhUrl        string
	EqualhImageId    int64
	Width            int64
	Height           int64
	Url800           string
	Url800ImageId    int64
	Caption          string
	AddDate          int64
}

func getGroupTable() (table string) {
	return getTable("group")
}

func getGroupDetailTable() (table string) {
	return getTable("group_detail")
}

//写入visual_group表
func SaveGroup(data SaveGroupData)  (id int64, err error) {
	sql := fmt.Sprintf("INSERT INTO %s (group_id,oneCategory,title,status,first_pic_id,group_pics_num,keywords,img_date,add_date) " +
		"VALUES(%d,%d,'%s',%d,'%s',%d,'%s',%d,%d)",
		getGroupTable(),data.GroupId,data.OneCategory,data.Title,data.Status,data.FirstPicId,data.GroupPicsNum,data.Keywords,data.ImgDate,data.AddDate)
	id, err = db.Insert(sql)
	if err != nil{
		logger.Error.Println("sql insert error:",err,"sql:",sql)
		return 0,err
	}
	return
}


//写入visual_group_detail表
func SaveGroupDetail(data SaveGroupData) (id int64, err error)  {
	sql := fmt.Sprintf("INSERT INTO %s (group_id,equalw_url,equalw_image_id,equalh_url,equalh_image_id,width,height,url800,url800_image_id,caption,add_date) " +
		"VALUES(%d,'%s',%d,'%s',%d,%d,%d,'%s',%d,'%s',%d)",
		getGroupDetailTable(),data.GroupId,data.EqualwUrl,data.EqualwImageId,data.EqualhUrl,data.EqualhImageId,data.Width,data.Height,data.Url800,data.Url800ImageId,data.Caption,data.AddDate)
	id, err = db.Insert(sql)
	if err != nil{
		logger.Error.Println("sql insert error:",err,"sql:",sql)
		return 0,err
	}
	return
}

