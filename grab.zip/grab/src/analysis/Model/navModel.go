package Model

import (
	"fmt"
	"libary/logger"
	"libary/db"
)

type SaveNavData struct {
	Id              int64
	NavName         string
	CategoryId      int64
	Type            int
    Url             string
	GrabUrl         string
    AddDate         int64
}

func getNavTable() (table string) {
	return getTable("nav")
}

//保存导航
func SaveNav(data SaveNavData) (id int64, err error) {
	sql := fmt.Sprintf("INSERT INTO %s (nav_name,category_id,type,url,grab_url,add_date) VALUES('%s',%d,%d,'%s','%s',%d)",
		getNavTable(),data.NavName,data.CategoryId,data.Type,data.Url,data.GrabUrl,data.AddDate)
	id, err = db.Insert(sql)
	if err != nil{
		logger.Error.Println("sql insert error:",err,"sql:",sql)
		return 0,err
	}
	return
}


