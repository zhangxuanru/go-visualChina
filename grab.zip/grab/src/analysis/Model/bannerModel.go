package Model

import (
	"fmt"
	"libary/db"
	"libary/logger"
)

type SaveBannerData struct {
	ID               int
	Type             int
	ImgId            int64
	Text             string
	OriginImgUrl     string
	Link             string
	LinkId           int
	RecommendType    int
	ImgWidth         int
	ImgHeight        int
	AddDate          int64
}

func getBannerTable() (table string) {
	return getTable("banner")
}

//写入visual_editorial_banner表
func SaveBanner(data SaveBannerData)  (id int64, err error) {
	sql := fmt.Sprintf("INSERT INTO %s (`type`,text,origin_imgurl,img_id,link,link_id,recommend_type,img_width,img_height,add_date) " +
		"VALUES(%d,'%s','%s',%d,'%s',%d,%d,%d,%d,%d)",
		getBannerTable(),data.Type,data.Text,data.OriginImgUrl,data.ImgId,data.Link,data.LinkId,data.RecommendType,data.ImgWidth,data.ImgHeight,data.AddDate)
	id, err = db.Insert(sql)
	if err != nil{
		logger.Error.Println("sql insert error:",err,"sql:",sql)
		return 0,err
	}
	return
}









