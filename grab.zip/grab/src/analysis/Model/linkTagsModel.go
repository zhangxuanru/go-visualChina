package Model

import (
	"fmt"
	"libary/db"
	"libary/logger"
)

type SaveLinkTagsData struct {
	Id              int64
	Title           string
	Link            string
	ItemId          int64
	ItemType        int
	CategoryId      int64
	Type            int
	AddDate         int64
}

func getLinkTagsTable() (table string) {
	return getTable("link_tags")
}

//保存链接标签
func SaveLinkTags(data SaveLinkTagsData) (id int64, err error) {
	sql := fmt.Sprintf("INSERT INTO %s (title,link,item_id,item_type,category_id,`type`,add_date) " +
		"VALUES('%s','%s',%d,%d,%d,%d,%d)",
		getLinkTagsTable(),data.Title,data.Link,data.ItemId,data.ItemType,data.CategoryId,data.Type,data.AddDate)
	id, err = db.Insert(sql)
	if err != nil{
		logger.Error.Println("sql insert error:",err,"sql:",sql)
		return 0,err
	}
	return
}
