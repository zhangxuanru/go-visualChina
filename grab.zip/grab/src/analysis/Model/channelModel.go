package Model

import (
	"fmt"
	"libary/db"
	"libary/logger"
)

type SaveChannelData struct {
	Id              int64
	Type            int
	CategoryId      int64
	CategoryPid     int64
	CategoryName    string
	Pid             int64
	Order           int
	GrabTotalCount  uint32
	TotalCount      uint32
	Status          int
	AddDate         int64
}

func getChannelTable() (table string) {
	return getTable("category")
}

//保存channel
func SaveChannel(data SaveChannelData) (id int64, err error) {
	sql := fmt.Sprintf("INSERT INTO %s (type,category_id,category_name,category_pid,pid,`order`,total_count,grab_total_count,`status`,add_date) " +
		"VALUES(%d,%d,'%s',%d,%d,%d,%d,%d,%d,%d)",
		getChannelTable(),data.Type,data.CategoryId,data.CategoryName,data.CategoryPid,data.Pid,data.Order,data.TotalCount,data.GrabTotalCount,data.Status, data.AddDate)
	id, err = db.Insert(sql)
	if err != nil{
		logger.Error.Println("sql insert error:",err,"sql:",sql)
		return 0,err
	}
	return
}


